const API_BASE = "http://localhost:8000";

export const getAlerts = async () => {
  const response = await fetch(`${API_BASE}/alerts`);
  return await response.json();
};

export const getTrafficLogs = async () => {
  const response = await fetch(`${API_BASE}/traffic`);
  return await response.json();
};

export const getNotifications = async () => {
  const response = await fetch(`${API_BASE}/notifications`);
  return await response.json();
};
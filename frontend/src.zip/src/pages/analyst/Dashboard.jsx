import React, { useState, useEffect } from 'react';
import { useNavigate, useLocation, Link } from 'react-router-dom';
import { FiEye } from 'react-icons/fi';
import './Dashboard.css';
import AnalystLayout from "../../components/AnalystLayout";

const Dashboard = () => {
  const navigate = useNavigate();
  const location = useLocation();
  const isActive = (path) => location.pathname === path;
  const [telegramMessage, setTelegramMessage] = useState("");
  const [backendStatus, setBackendStatus] = useState("Not tested");
  const [backendAlerts, setBackendAlerts] = useState([]);
  useEffect(() => {
  const testConnection = async () => {
    try {
      const res = await fetch("http://127.0.0.1:8000/alerts");
      const data = await res.json();

      console.log("Backend response:", data);
      
      setBackendAlerts(data.items || []);
      
      setBackendStatus(
        `Connected: ${data.items ? data.items.length : 0} alerts found`
      );
    } catch (err) {
      console.error("Connection failed:", err);
      setBackendStatus("Connection failed");
    }
  };

  testConnection();
}, []);
  // REMOVE THIS when backend is implemented
  const TOKEN = "8500029016:AAG13AhvWboYuAQSG4CmTh8RppPgu8G2aKI";
  const CHAT_ID = "1733380706"; //This is Dion's chat ID, used for testing. Replace this with the user's ID when backend is implemented.

  // Test the box to send any direcct message to the bot, back to the phone.
  const sendTelegramMessage = async () => {
    if (!telegramMessage.trim()) return;

    try {
      const res = await fetch(
        //"http://localhost:5000/send-telegram" (replace line below when bkend is done)
        `https://api.telegram.org/bot${TOKEN}/sendMessage`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json"
        },
        body: JSON.stringify({ 
          chat_id: CHAT_ID,
          text: telegramMessage })
      });

      const data = await res.json();
      alert("Telegram alert sent!");
      setTelegramMessage("");
    } catch (err) {
      console.error(err);
      alert("Failed to send Telegram message.");
    }
  };

  // Try to send the displayed data back to the bot.
  const sendAlertToTelegram = async (alert) => {
    const message = `IDS ALERT

  Type: ${alert.type}
  Source: ${alert.src}
  Destination: ${alert.dst}
  Severity: ${alert.severity}
  IDS: ${alert.ids}
  Time: ${alert.time}`;

    try {
      const response = await fetch(
        `https://api.telegram.org/bot${TOKEN}/sendMessage`,
        {
          method: "POST",
          headers: {
            "Content-Type": "application/json"
          },
          body: JSON.stringify({
            chat_id: CHAT_ID,
            text: message
          })
        }
      );

      const data = await response.json();
      console.log(data);
      alert("Alert sent to Telegram!");
    } catch (err) {
      console.error(err);
      alert("Failed to send alert.");
    }
  };

  // Sample data for the table – now with unique IDs
  const recentAlerts = [
    { id: 1, severity: 'High', type: 'SQLI', src: '192.168.1.100', dst: '10.0.0.12', ids: 'Snort', time: '30s ago', progress: 'New' },
    { id: 2, severity: 'High', type: 'Malware', src: '192.168.1.120', dst: '10.0.0.5', ids: 'Suricata', time: '1m ago', progress: 'New' },
    { id: 3, severity: 'Medium', type: 'Suspicious login', src: '203.45.67.89', dst: '45.67.89.12', ids: 'Zeek', time: '2m ago', progress: 'In Progress' },
    { id: 4, severity: 'Low', type: 'Phishing', src: '192.168.1.92', dst: '10.0.0.10', ids: 'Snort', time: '5m ago', progress: 'Resolved' },
    { id: 5, severity: 'Low', type: 'Port scan', src: '178.23.156.42', dst: '8.8.8.8', ids: 'Kismet', time: '10m ago', progress: 'Resolved' },
    { id: 6, severity: 'High', type: 'Ransomware', src: '192.168.1.45', dst: '10.0.0.22', ids: 'Suricata', time: '15m ago', progress: 'In Progress' },
    { id: 7, severity: 'Medium', type: 'Brute Force', src: '104.28.12.34', dst: '192.168.1.1', ids: 'Snort', time: '22m ago', progress: 'New' },
    { id: 8, severity: 'Low', type: 'Port scan', src: '8.8.8.8', dst: '192.168.1.100', ids: 'Kismet', time: '32m ago', progress: 'Resolved' },
    { id: 9, severity: 'High', type: 'C2 Beacon', src: '45.33.22.11', dst: '10.0.0.50', ids: 'Zeek', time: '45m ago', progress: 'In Progress' },
    { id: 10, severity: 'Medium', type: 'SQL Injection', src: '203.0.113.5', dst: '10.0.0.15', ids: 'Snort', time: '1h ago', progress: 'Resolved' },
    { id: 11, severity: 'Low', type: 'Failed Login', src: '192.168.1.200', dst: '10.0.0.8', ids: 'Zeek', time: '2h ago', progress: 'Resolved' },
    { id: 12, severity: 'High', type: 'Data Exfiltration', src: '198.51.100.77', dst: '10.0.0.99', ids: 'Suricata', time: '3h ago', progress: 'In Progress' },
    { id: 13, severity: 'Medium', type: 'DDoS', src: '192.168.1.150', dst: '10.0.0.20', ids: 'Snort', time: '4h ago', progress: 'In Progress' },
    { id: 14, severity: 'Low', type: 'Reconnaissance', src: '104.16.45.33', dst: '192.168.1.10', ids: 'Zeek', time: '5h ago', progress: 'Resolved' },
  ];

  // Handler for viewing alert details – navigates to details page with alert data
  const handleViewAlert = (alert) => {
    navigate(`/alert/${alert.id}`, { state: { alert } });
  };

  // Pie chart component (unchanged)
  const PieChart = () => {
    const data = [
      { value: 175, color: '#28a745' }, // Low
      { value: 58, color: '#ffc107' },  // Medium
      { value: 12, color: '#dc3545' },  // High
    ];
    const total = data.reduce((sum, d) => sum + d.value, 0);
    let cumulativeAngle = 0;

    const describeSegment = (value, startAngle) => {
      const angle = (value / total) * 2 * Math.PI;
      const endAngle = startAngle + angle;
      const x1 = 50 + 40 * Math.sin(startAngle);
      const y1 = 50 - 40 * Math.cos(startAngle);
      const x2 = 50 + 40 * Math.sin(endAngle);
      const y2 = 50 - 40 * Math.cos(endAngle);
      const largeArcFlag = angle > Math.PI ? 1 : 0;
      return `M 50,50 L ${x1},${y1} A 40,40 0 ${largeArcFlag} 1 ${x2},${y2} Z`;
    };

    return (
      <div className="pie-chart-container">
        <svg viewBox="0 0 100 100" width="100%" height="120">
          {data.map((d, i) => {
            const path = describeSegment(d.value, cumulativeAngle);
            cumulativeAngle += (d.value / total) * 2 * Math.PI;
            return <path key={i} d={path} fill={d.color} stroke="#000" strokeWidth="0.5" />;
          })}
          <circle cx="50" cy="50" r="20" fill="white" stroke="#000" strokeWidth="1" />
        </svg>
      </div>
    );
  };

  return (
    <div className="dashboard-container">
      {/* Sidebar (unchanged) */}
      <aside className="sidebar">
        <div className="sidebar-header">Intrusion Detection</div>
        <nav className="sidebar-nav">
          <div className="nav-section">
            <ul>
              <li className="active">Dashboard</li>
              <li className={isActive('/alerts') ? 'active' : ''}>
                <Link to="/alerts">Alerts</Link>
              </li>
              <li>Network Traffic</li>
              <li>Reports</li>
              <li>Settings</li>
            </ul>
          </div>
        </nav>
        <div className="sidebar-user">
          <hr className="divider" />
          <div className="user-info">
            <span className="user-role">Analyst</span>
            <span className="user-name">Security Analyst 1</span>
          </div>
        </div>
      </aside>

      {/* Main Content */}
      <main className="dashboard-main">
        {/* Summary Cards (unchanged) */}
        <div className="summary-cards">
          <div className="card card-total">
            <span className="card-icon">!</span>
            <div className="card-label">Total Alerts</div>
            <hr />
            <div className="card-value">245</div>
          </div>
          <div className="card card-high">
            <span className="card-icon">!</span>
            <div className="card-label">High Severity</div>
            <hr />
            <div className="card-value">12</div>
          </div>
          <div className="card card-medium">
            <span className="card-icon">!</span>
            <div className="card-label">Medium Severity</div>
            <hr />
            <div className="card-value">58</div>
          </div>
          <div className="card card-low">
            <span className="card-icon">!</span>
            <div className="card-label">Low Severity</div>
            <hr />
            <div className="card-value">175</div>
          </div>
        </div>
        <div style={{ margin: "15px 0", color: "white", fontWeight: "bold" }}>
          Backend status: {backendStatus}
        </div>
        {/* Threat Trends + Alerts Distribution (unchanged) */}
        <div className="trends-distribution-row">
          <div className="trends-card">
            <div className="trends-header">
              <span>Threat Trends</span>
              <select className="time-filter">
                <option>24 hours</option>
                <option>7 days</option>
                <option>30 days</option>
              </select>
            </div>
            <div className="chart-placeholder">📈 Trend Chart</div>
          </div>
          <div className="distribution-card">
            <div className="distribution-header">Alerts Distribution</div>
            <PieChart />
          </div>
        </div>

        {/* Recent Alerts Table with View Column */}
        <div className="recent-alerts-section">
          <h2>Recent Alerts</h2>
          <table className="alerts-table">
            <thead>
              <tr>
                <th>Severity</th>
                <th>Alert Type</th>
                <th>Source IP</th>
                <th>Destination IP</th>
                <th>IDS source</th>
                <th>Time</th>
                <th>Progress</th>
                <th>View</th>
                <th>Telegram</th>
              </tr>
            </thead>
            <tbody>
              {backendAlerts.map((alert) => (
                <tr key={alert.id}>
                  <td>
                    <span className={`severity-badge ${alert.severity_label}`}>
                      {alert.severity_label}
                    </span>
                  </td>
                  
                  <td>{alert.signature}</td>
                  
                  <td>{alert.src_ip}</td>
                  
                  <td>{alert.dest_ip}</td>
                  
                  <td>{alert.proto}</td>
                  
                  <td>{new Date(alert.timestamp).toLocaleString()}</td>
                  
                  <td>
                    <span className={`progress-badge ${alert.status}`}>
                      {alert.status}
                    </span>
                  </td>
                  <td>
                    <button
                      className="view-btn"
                      onClick={() => handleViewAlert(alert)}
                      title="View alert details"
                    >
                      <FiEye />
                    </button>
                  </td>
                  <td>
                    <button
                      className="telegram-btn"
                      onClick={() => sendAlertToTelegram(alert)}
                      title="Send to Telegram"
                    >
                      Send
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>

        {/* Telegram Alert Section */}
        <div style={{
          marginTop: "30px",
          padding: "20px",
          background: "#1e293b",
          borderRadius: "8px"
        }}>
          <h2>Telegram Alert Test</h2>

          <div style={{ display: "flex", gap: "10px", marginTop: "10px" }}>
            <input
              type="text"
              placeholder="Type Telegram message..."
              value={telegramMessage}
              onChange={(e) => setTelegramMessage(e.target.value)}
              style={{
                flex: 1,
                padding: "10px",
                borderRadius: "6px",
                border: "1px solid #334155",
                background: "#0f172a",
                color: "white"
              }}
            />

            <button
              onClick={sendTelegramMessage}
              style={{
                padding: "10px 20px",
                background: "#3b82f6",
                border: "none",
                borderRadius: "6px",
                color: "white",
                cursor: "pointer"
              }}
            >
              Send
            </button>
          </div>
        </div>

        {/* Footer */}
        <footer className="footer">
          <p>2026 Intrusion Detection Dashboard</p>
        </footer>
      </main>
    </div>
  );
};

export default Dashboard;
